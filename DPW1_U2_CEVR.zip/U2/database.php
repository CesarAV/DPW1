<?php
   class Database{
       private $con;
       
   }
?>